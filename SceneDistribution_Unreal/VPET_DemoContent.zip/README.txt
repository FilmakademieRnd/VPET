-- VPET Demo Content --

Sample level for testing VPET for Unreal.
Simple place the content files in your project.
Make sure the VPET plug-in is installed, as the level requires the VPETModule actor.